package com.example.hayatai

import android.app.Activity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.content.Intent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var speakButton: Button
    private lateinit var recognizer: SpeechRecognizer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this)
        result = TextView(this)
        speakButton = Button(this)

        status.text = "HAYAT AI तयार आहे"
        result.text = "बोलण्यासाठी बटण दाबा"
        speakButton.text = "🎙️ बोला"

        val layout = android.widget.LinearLayout(this)
        layout.orientation = android.widget.LinearLayout.VERTICAL
        layout.setPadding(30, 100, 30, 30)

        layout.addView(status)
        layout.addView(result)
        layout.addView(speakButton)

        setContentView(layout)

        tts = TextToSpeech(this, this)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)

        speakButton.setOnClickListener {
            startListening()
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "आवाज ओळखण्याची सुविधा उपलब्ध नाही"
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )
                val text = matches?.firstOrNull() ?: ""
                result.text = text
                respond(text)
            }

            override fun onReadyForSpeech(params: Bundle?) {
                status.text = "ऐकत आहे..."
            }

            override fun onError(error: Int) {
                status.text = "पुन्हा प्रयत्न करा"
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        recognizer.startListening(intent)
    }

    private fun respond(text: String) {
        val reply = when {
            text.contains("नमस्कार") || text.contains("हॅलो") ->
                "नमस्कार! मी HAYAT AI आहे."

            text.contains("यूट्यूब") || text.contains("youtube") -> {
                val launch = packageManager.getLaunchIntentForPackage(
                    "com.google.android.youtube"
                )
                if (launch != null) startActivity(launch)
                "यूट्यूब उघडण्याचा प्रयत्न करत आहे."
            }

            else -> "तुम्ही म्हणालात: $text"
        }

        status.text = reply
        tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "hayat")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("mr", "IN")
        }
    }

    override fun onDestroy() {
        if (::recognizer.isInitialized) recognizer.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
